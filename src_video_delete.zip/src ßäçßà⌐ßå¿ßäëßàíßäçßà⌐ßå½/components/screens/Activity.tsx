import {View, Text} from 'react-native';
import React from 'react';

const Activity = () => {
  return (
    <View>
      <Text>Activity</Text>
    </View>
  );
};

export default Activity;
