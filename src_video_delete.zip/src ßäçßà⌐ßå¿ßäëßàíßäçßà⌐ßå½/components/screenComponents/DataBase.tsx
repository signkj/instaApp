//Videos data

export const videoData = [
  {
    video: require('../../storage/videos/video1.mp4'),
    title: 'Ram_Charn',
    description: 'Feel the buity of nature',
    likes: '245k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video2.mp4'),
    title: 'The_Groot',
    description: "It's tea time",
    likes: '656k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video3.mp4'),
    title: 'leverland',
    description: 'Feel the buity of nature',
    likes: '243k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video4.mp4'),
    title: 'mr. bean',
    description: 'How cute it is !!',
    likes: '233k',
    isLike: false,
  },
];
