//Videos data

export const videoData = [
  {
    video: require('../../storage/videos/video1.mp4'),
    postProfile: require('../../storage/images/post1.jpg'),
    title: 'Ram_Charn',
    description: 'Feel the buity of nature',
    likes: '245k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video2.mp4'),
    postProfile: require('../../storage/images/post2.jpg'),
    title: 'The_Groot',
    description: "It's tea time",
    likes: '656k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video3.mp4'),
    postProfile: require('../../storage/images/post3.jpg'),
    title: 'leverland',
    description: 'Feel the buity of nature',
    likes: '243k',
    isLike: false,
  },
  {
    video: require('../../storage/videos/video4.mp4'),
    postProfile: require('../../storage/images/post4.jpg'),
    title: 'mr. bean',
    description: 'How cute it is !!',
    likes: '233k',
    isLike: false,
  },
];
