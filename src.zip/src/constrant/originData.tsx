export const StoryInfo = [
  {
    id: 1,
    name: 'Your story',
    image: require('../storage/images/userProfile.png'),
  },
  {
    id: 0,
    name: 'Ram_Charan',
    image: require('../storage/images/profile1.jpg'),
  },
  {
    id: 0,
    name: 'Tom',
    image: require('../storage/images/profile2.jpg'),
  },
  {
    id: 0,
    name: 'The_Groot',
    image: require('../storage/images/profile3.jpg'),
  },
  {
    id: 0,
    name: 'loverland',
    image: require('../storage/images/profile4.jpg'),
  },
  {
    id: 0,
    name: 'chillhouse',
    image: require('../storage/images/profile5.jpg'),
  },
];
